/*
 * File Name: Program.java
 * Version: 1.0
 * Description: Main file of the KNN Program. The program expects a user to provide
 * 				a file path containing a dataset as well as the k-value to which 
 * 				the algorithm will determine the K-Nearest Neighbor.
 * Authors: Milano Hyacinthe, Ashma Giri, Danny Lopes
 * UMUC
 * SWEN 670 
 */


package parkinsonUI;
import parkinsonclassifier.*;
import java.util.*;
import parkinsonData.DataStorage;

/**
 * Main class constructor.
 */
public class Program {

    public static void main(String[] args) {

		ParkinsonManager userInput = new ParkinsonManager();
                String trainFile = ""; //Store train file path
		String testFile = ""; //Store test file path
                
                		Scanner scan = new Scanner(System.in);
                                
                System.out.println("Enter train file path:");
                trainFile = scan.nextLine();
                		System.out.println("Enter test file path:");
		testFile = scan.nextLine();
                System.out.println("Enter CSV result file location:");
              DataStorage.resultFile = scan.nextLine();
               		
            userInput.Manager(trainFile, testFile);
System.out.println("Result data is saved in: " + DataStorage.resultFile);
    }
}
