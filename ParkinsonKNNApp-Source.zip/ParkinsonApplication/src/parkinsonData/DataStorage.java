/*
 * File Name: DataStorage.java
 * Version: 1.0
 * Description: 
 * Authors: Milano Hyacinthe, Ashma Giri, Danny Lopes
 * UMUC
 * SWEN 670 
 */

package parkinsonData;
import java.util.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DataStorage {
public static String resultFile; 

    /**
     * [DataStorage - class constructor]
     */
    public DataStorage(){
      
    }

    public static String colName(){
    return "test name" + ","
            + "MDVP:Fo(Hz)" + ","
            + "MDVP:Fhi(Hz)" + ","
            + "MDVP:Flo(Hz)" + ","
            + "MDVP:Jitter(%)" + ","
            + "MDVP:Jitter(Abs)" + ","
            + "MDVP:RAP" + ","
            + "MDVP:PPQ" + ","
            + "Jitter:DDP" + ","
            + "MDVP:Shimmer" + ","
            + "MDVP:Shimmer(dB)" + ","
            + "Shimmer:APQ3" + ","
            + "Shimmer:APQ5" + ","
            + "MDVP:APQ" + ","
            + "Shimmer:DDA" + ","
            + "NHR" + ","
            + "HNR" + ","
            + "status" + ","
            + "RPDE" + ","
            + "DFA" + ","
            + "spread1" + ","
            + "spread2" + ","
            + "D2" + ","
            + "PPE" + ","
            + "Prediction";
    
}
    
    /**
     * [StoreResult - store result in resultData.csv]
     * @param String line 
     */
    public static void StoreResult(String line){
       PrintWriter output = null; 
       //String resultFile = "./data/resultData.csv";
        try{
            
            output = new PrintWriter(new BufferedWriter(new FileWriter(resultFile, true)));
            
            output.println(line);
        } catch (Exception e){
        
        System.err.println("Result File not found Error: " + e);
        }
        finally {
            if(output != null)
                output.close();
        } 
    }


}
